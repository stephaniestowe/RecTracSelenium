﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RecTracPom;
using RecTracActions;

namespace RecTracSelenium
{
    [TestClass]
    public class SessionLoadLoginTests
    {
        private const string url = "http://qa-stephanies:4180/wbwsc/clientdemo.wsc/login.html?InterfaceParameter=RecTracNextGenStephanie#/login";

        [TestMethod]
        public void OpenandCloseTest()
        {

            Session.OpenStandard(BrowserWindow.Browsers.Chrome, url, "zzz", "password");
            Session.CloseStandard();

        }
    }
}
