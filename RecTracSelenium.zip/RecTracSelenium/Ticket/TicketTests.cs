﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RecTracPom;
using RecTracActions;
using Z.Expressions;

namespace RecTracSelenium.Ticket
{
    [TestClass]
    public class TicketTests
    {
        private const string url = "http://qa-stephanies:4180/wbwsc/clientdemo.wsc/login.html?InterfaceParameter=RecTracNextGenStephanie#/login";

        private TestContext testContextInstance;
        public TestContext TestContext
        {
            get { return testContextInstance; }
            set { testContextInstance = value; }
        }

        [TestInitialize]
        public void Startup()
        {
            Session.OpenStandard(BrowserWindow.Browsers.Chrome, url, "zzz", "password");
        }

        [TestCleanup]
        public void Cleanup()
        {
            Session.CloseStandard();
        }
        [TestMethod]
        public void AddDeleteTicket()
        {
            const string ticketCode = "This is a ticket";
            RecTracActions.Ticket.NavigateTicketManagement();
            RecTracActions.Ticket.AddTicket(ticketCode);
            bool exists = RecTracActions.Ticket.IsTicketExists(ticketCode);
            Assert.IsTrue(exists);
            RecTracActions.Ticket.DeleteTicket(ticketCode);
            exists = RecTracActions.Ticket.IsTicketExists(ticketCode);
            Assert.IsFalse(exists);
        }

        [TestMethod]
        // obviously we would not hard cord file system stuff...
        [DataSource("Microsoft.VisualStudio.TestTools.DataSource.CSV", "C:\\Users\\StephanieAs.VSI.NET\\source\\repos\\RecTracSelenium\\RecTracSelenium\\SupportingFiles\\CrudDtt.csv", "DDT#csv", DataAccessMethod.Sequential)]
        public void Crud()
        {
            //const string addCode = "This is the add code";
            string sEval = (string)TestContext.DataRow["NavigateTo"];
            Z.Expressions.Eval.Execute(sEval);
        }

    }
}
