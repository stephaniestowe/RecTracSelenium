﻿using OpenQA.Selenium;
using RecTracPom.OnScreenElements;
using System.Collections.ObjectModel;

namespace RecTracPom
{
    public static class ModulePosTicketManagement
    {
        private static By byTicketCodeFilter = By.XPath("//input[contains(@name,'filter_psticketmain_ticketcode')]");
        private static By byTicketDataTable = By.XPath("//table[starts-with(@id, 'psticketmainmain_datagrid')]");

        public static void SetTicketCodeFilter(string ticketCode)
        {
            Textbox txtFilterCode = new Textbox(byTicketCodeFilter);
            txtFilterCode.SetText(ticketCode, Textbox.KeyToPress.Enter);
            
        }

        public static int TicketCount
        {
            get
            {
                Table table = new Table(byTicketDataTable);
                return table.RowCount();
            }
        }

        public static bool IsTicketExists(string ticketCode)
        {
           
            By byCellTicketCode = By.XPath("//td[@data-property='psticketmain_ticketcode']");
            SetTicketCodeFilter(ticketCode);
            Table table = new Table(byTicketDataTable);
            
            foreach (IWebElement row in table.Rows)
            {
                try
                {
                    ReadOnlyCollection<IWebElement> cols = row.FindElements(byCellTicketCode);

                    foreach (IWebElement col in cols)
                    {
                        if (col.Text.ToLower() == ticketCode.ToLower())
                        {
                            return true;
                        }
                    }
                }
                catch
                {
                    return false;
                }

            }
            return false;
        }

    }
}
