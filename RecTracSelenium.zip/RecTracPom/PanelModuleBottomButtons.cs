﻿using OpenQA.Selenium;
using RecTracPom.OnScreenElements;
using System.Threading;

namespace RecTracPom
{
    public static class PanelModuleBottomButtons
    {
        private static By byAddButton = By.XPath("//button[@title='Add']");
        private static By byMoreButton = By.XPath("//button[@title='More']");
        private static By byDeleteButton = By.XPath("//button[@title='Delete']");

        public static void AddButtonClick()
        {
            Button btnAdd = new Button(byAddButton);

            //TODO: replace this with a correct wait sceme
            Thread.Sleep(5000);

            btnAdd.Click();
        }

        public static void MoreButtonClick()
        {
            Button btnMore = new Button(byMoreButton);
            btnMore.Click();
        }

        public static void DeleteButtonClick()
        {
            Button btnDelete = new Button(byDeleteButton);
            btnDelete.Click();
        }
    }
}
