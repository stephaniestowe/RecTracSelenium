﻿using OpenQA.Selenium;
using RecTracPom.OnScreenElements;

namespace RecTracPom
{
    public class DialogDefaultRecordAdd : Dialog
    {
        public DialogDefaultRecordAdd(string title) : base(title)
        {

        }


    }
}
