﻿namespace RecTracPom
{
    public class DialogInformation : OnScreenElements.Dialog
    {
        public DialogInformation(string title) : base(title)
        {

        }
    }
}
