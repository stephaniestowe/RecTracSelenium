﻿using OpenQA.Selenium;
using RecTracPom.OnScreenElements;

namespace RecTracPom
{
    public static class ModulePosTicketUpdate
    {

        private static By byTicketCode = By.XPath("//input[starts-with(@id,'psticketmain_ticketcode')]");
        private static By bySave = By.XPath("//button[@title='Save']");
        public static void SetTicketCode(string ticketCode)
        {
            Textbox txtTicketCode = new OnScreenElements.Textbox(byTicketCode);
            txtTicketCode.SetText(ticketCode);
            Button btnSave = new Button(bySave);
            btnSave.Click();
        }


    }
}
